import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  initDatabase,
  getServers,
  addServer as dbAddServer,
  updateServer as dbUpdateServer,
  deleteServer as dbDeleteServer,
  getDefaultServer,
  getCachedUsers,
  getServerStats,
  cacheUsers,
  updateServerSyncTime,
  Server,
  CachedUser,
} from '../database/database';
import { sasApi, SyncResult, SASUser } from '../api/sasApi';

interface AppContextType {
  // Database state
  isDbReady: boolean;

  // Servers
  servers: Server[];
  currentServer: Server | null;
  addServer: (server: Omit<Server, 'id' | 'created_at'>) => Promise<number>;
  updateServer: (id: number, server: Partial<Server>) => Promise<void>;
  deleteServer: (id: number) => Promise<void>;
  selectServer: (server: Server) => Promise<boolean>;

  // Users/Subscribers
  subscribers: CachedUser[];
  isLoadingSubscribers: boolean;
  refreshSubscribers: () => Promise<void>;
  searchSubscribers: (query: string) => Promise<CachedUser[]>;

  // Statistics
  stats: {
    totalUsers: number;
    activeUsers: number;
    expiredUsers: number;
    totalDebt: number;
    unpaidInvoices: number;
  };
  refreshStats: () => Promise<void>;

  // Sync
  isSyncing: boolean;
  syncStatus: string;
  syncData: () => Promise<SyncResult>;

  // Connection
  isConnected: boolean;
  testConnection: (server: Server) => Promise<{ success: boolean; message: string }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isDbReady, setIsDbReady] = useState(false);
  const [servers, setServers] = useState<Server[]>([]);
  const [currentServer, setCurrentServer] = useState<Server | null>(null);
  const [subscribers, setSubscribers] = useState<CachedUser[]>([]);
  const [isLoadingSubscribers, setIsLoadingSubscribers] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    expiredUsers: 0,
    totalDebt: 0,
    unpaidInvoices: 0,
  });

  // Initialize database
  useEffect(() => {
    const init = async () => {
      try {
        await initDatabase();
        setIsDbReady(true);

        // Load servers
        const loadedServers = await getServers();
        setServers(loadedServers);

        // Set default server if exists
        const defaultServer = await getDefaultServer();
        if (defaultServer) {
          await selectServer(defaultServer);
        }
      } catch (error) {
        console.error('Database init error:', error);
      }
    };

    init();
  }, []);

  // Add server
  const addServer = async (server: Omit<Server, 'id' | 'created_at'>): Promise<number> => {
    const id = await dbAddServer(server);
    const updatedServers = await getServers();
    setServers(updatedServers);
    return id;
  };

  // Update server
  const updateServer = async (id: number, server: Partial<Server>): Promise<void> => {
    await dbUpdateServer(id, server);
    const updatedServers = await getServers();
    setServers(updatedServers);

    // Update current server if it's the one being updated
    if (currentServer?.id === id) {
      const updated = updatedServers.find(s => s.id === id);
      if (updated) {
        setCurrentServer(updated);
        sasApi.setServer({
          ...updated,
          is_default: updated.is_default === 1,
        });
      }
    }
  };

  // Delete server
  const deleteServer = async (id: number): Promise<void> => {
    await dbDeleteServer(id);
    const updatedServers = await getServers();
    setServers(updatedServers);

    // Clear current server if it's the one being deleted
    if (currentServer?.id === id) {
      setCurrentServer(null);
      sasApi.clearServer();
      setIsConnected(false);
      setSubscribers([]);
    }
  };

  // Select server
  const selectServer = async (server: Server): Promise<boolean> => {
    setCurrentServer(server);
    sasApi.setServer({
      ...server,
      is_default: server.is_default === 1,
    });

    // Try to login
    const loginResult = await sasApi.login();
    setIsConnected(loginResult.success);

    if (loginResult.success) {
      // Load cached data
      await refreshSubscribers();
      await refreshStats();
    }

    return loginResult.success;
  };

  // Refresh subscribers from cache
  const refreshSubscribers = async () => {
    if (!currentServer?.id) return;

    setIsLoadingSubscribers(true);
    try {
      const users = await getCachedUsers(currentServer.id);
      setSubscribers(users);
    } catch (error) {
      console.error('Error loading subscribers:', error);
    } finally {
      setIsLoadingSubscribers(false);
    }
  };

  // Search subscribers
  const searchSubscribers = async (query: string): Promise<CachedUser[]> => {
    if (!currentServer?.id || !query.trim()) {
      return subscribers;
    }

    const { searchCachedUsers } = await import('../database/database');
    return await searchCachedUsers(currentServer.id, query);
  };

  // Refresh statistics
  const refreshStats = async () => {
    if (!currentServer?.id) return;

    try {
      const serverStats = await getServerStats(currentServer.id);
      setStats(serverStats);
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  // Sync data from server
  const syncData = async (): Promise<SyncResult> => {
    if (!currentServer) {
      return { success: false, error: 'لم يتم تحديد السيرفر' };
    }

    setIsSyncing(true);
    setSyncStatus('جاري الاتصال بالسيرفر...');

    try {
      // Ensure connected
      if (!isConnected) {
        const loginResult = await sasApi.login();
        if (!loginResult.success) {
          return { success: false, error: loginResult.message || 'فشل الاتصال' };
        }
        setIsConnected(true);
      }

      // Sync users
      setSyncStatus('جاري جلب المشتركين...');
      const usersResult = await sasApi.getUsers(1, 1000);

      if (usersResult.success && usersResult.users) {
        const cachedUsersList: CachedUser[] = usersResult.users.map((user: SASUser) => ({
          server_id: currentServer.id!,
          user_id: user.id,
          username: user.username,
          firstname: user.firstname,
          lastname: user.lastname,
          email: user.email,
          phone: user.phone,
          balance: user.balance || '0',
          profile: user.profile,
          status: user.status || 'active',
          expiration: user.expiration,
          created_at: user.created_at || new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }));

        await cacheUsers(currentServer.id!, cachedUsersList);
      }

      // Update sync time
      await updateServerSyncTime(currentServer.id!);

      // Refresh local data
      await refreshSubscribers();
      await refreshStats();

      setSyncStatus('تمت المزامنة بنجاح');

      return {
        success: true,
        usersCount: usersResult.users?.length || 0,
      };
    } catch (error) {
      setSyncStatus('فشلت المزامنة');
      return { success: false, error: 'حدث خطأ أثناء المزامنة' };
    } finally {
      setIsSyncing(false);
    }
  };

  // Test connection
  const testConnection = async (server: Server): Promise<{ success: boolean; message: string }> => {
    return await sasApi.testConnection({
      ...server,
      is_default: server.is_default === 1,
    });
  };

  const value: AppContextType = {
    isDbReady,
    servers,
    currentServer,
    addServer,
    updateServer,
    deleteServer,
    selectServer,
    subscribers,
    isLoadingSubscribers,
    refreshSubscribers,
    searchSubscribers,
    stats,
    refreshStats,
    isSyncing,
    syncStatus,
    syncData,
    isConnected,
    testConnection,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
