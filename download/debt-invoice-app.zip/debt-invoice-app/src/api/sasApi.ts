import CryptoJS from 'crypto-js';
import axios, { AxiosInstance, AxiosError } from 'axios';

// API Configuration
const ENCRYPTION_KEY = 'abcdefghijuklmno0123456789012345';

// Types
export interface ServerConfig {
  id?: number;
  name: string;
  url: string;
  username: string;
  password: string;
  is_default?: boolean;
}

export interface SASUser {
  id: number;
  username: string;
  firstname?: string;
  lastname?: string;
  email?: string;
  phone?: string;
  balance: string;
  profile?: string;
  status: string;
  expiration?: string;
  enabled?: number;
  created_at?: string;
  last_online?: string;
  download?: string;
  upload?: string;
}

export interface SASDevice {
  id: number;
  user_id: number;
  device_name?: string;
  mac_address?: string;
  ip_address?: string;
  last_seen?: string;
  status: string;
}

export interface SASInvoice {
  id: number;
  invoice_no: string;
  user_id: number;
  amount: string;
  type: string;
  description?: string;
  paid: boolean;
  date: string;
  created_by?: string;
}

export interface SASProfile {
  id: number;
  name: string;
  description?: string;
  price: string;
  download_speed?: string;
  upload_speed?: string;
}

export interface SASOnlineUser {
  id: number;
  username: string;
  ip: string;
  mac?: string;
  session_time?: string;
  download?: string;
  upload?: string;
  profile?: string;
}

export interface SyncResult {
  success: boolean;
  usersCount?: number;
  devicesCount?: number;
  invoicesCount?: number;
  error?: string;
}

class SASApiService {
  private adminApi: AxiosInstance | null = null;
  private token: string | null = null;
  private currentServer: ServerConfig | null = null;

  // Encrypt payload for POST requests
  private encryptPayload(data: object): string {
    const jsonString = JSON.stringify(data);
    const encrypted = CryptoJS.AES.encrypt(jsonString, ENCRYPTION_KEY);
    return encrypted.toString();
  }

  // Set server configuration
  setServer(server: ServerConfig): void {
    this.currentServer = server;
    const baseUrl = server.url.replace(/\/$/, '');

    this.adminApi = axios.create({
      baseURL: `${baseUrl}/admin/api/index.php/api`,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Reset token when server changes
    this.token = null;
  }

  // Clear current server
  clearServer(): void {
    this.currentServer = null;
    this.adminApi = null;
    this.token = null;
  }

  // Get current server
  getCurrentServer(): ServerConfig | null {
    return this.currentServer;
  }

  // Login to SAS server
  async login(): Promise<{ success: boolean; token?: string; message?: string }> {
    if (!this.adminApi || !this.currentServer) {
      return { success: false, message: 'لم يتم تحديد السيرفر' };
    }

    try {
      const payload = this.encryptPayload({
        username: this.currentServer.username,
        password: this.currentServer.password,
        language: 'ar',
      });

      const response = await this.adminApi.post('/login', { payload });

      if (response.data.status === 200 && response.data.token) {
        this.token = response.data.token;
        return { success: true, token: response.data.token };
      }

      return { success: false, message: response.data.message || 'فشل تسجيل الدخول' };
    } catch (error: unknown) {
      const axiosError = error as AxiosError<{ message?: string }>;
      return {
        success: false,
        message: axiosError.response?.data?.message || 'حدث خطأ في الاتصال بالسيرفر'
      };
    }
  }

  // Test server connection
  async testConnection(server: ServerConfig): Promise<{ success: boolean; message: string }> {
    const originalServer = this.currentServer;
    const originalApi = this.adminApi;
    const originalToken = this.token;

    try {
      this.setServer(server);
      const result = await this.login();

      if (result.success) {
        return { success: true, message: 'تم الاتصال بنجاح' };
      }
      return { success: false, message: result.message || 'فشل الاتصال' };
    } finally {
      // Restore original server
      this.currentServer = originalServer;
      this.adminApi = originalApi;
      this.token = originalToken;
    }
  }

  // Make authenticated request
  private async makeRequest<T>(
    method: 'GET' | 'POST',
    endpoint: string,
    data?: object
  ): Promise<{ success: boolean; data?: T; message?: string }> {
    if (!this.adminApi || !this.token) {
      return { success: false, message: 'غير متصل بالسيرفر' };
    }

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${this.token}`,
        },
      };

      let response;
      if (method === 'GET') {
        response = await this.adminApi.get(endpoint, config);
      } else {
        const payload = data ? this.encryptPayload(data) : '';
        response = await this.adminApi.post(endpoint, { payload }, config);
      }

      if (response.data.status === 200 || response.data.status === true) {
        return { success: true, data: response.data };
      }

      return { success: false, message: response.data.message || 'حدث خطأ' };
    } catch (error: unknown) {
      const axiosError = error as AxiosError<{ message?: string }>;
      if (axiosError.response?.status === 401) {
        this.token = null;
        return { success: false, message: 'انتهت الجلسة، يرجى إعادة تسجيل الدخول' };
      }
      return {
        success: false,
        message: axiosError.response?.data?.message || 'حدث خطأ في الاتصال'
      };
    }
  }

  // ============ USERS ============

  // Get users list with pagination
  async getUsers(page: number = 1, count: number = 50, status?: string): Promise<{
    success: boolean;
    users?: SASUser[];
    total?: number;
    message?: string;
  }> {
    let endpoint = `/index/user?page=${page}&count=${count}`;

    if (status) {
      endpoint += `&status=${status}`;
    }

    const result = await this.makeRequest<{ data: SASUser[]; total?: number }>('GET', endpoint);

    if (result.success && result.data) {
      return {
        success: true,
        users: result.data.data || [],
        total: result.data.total,
      };
    }

    return { success: false, message: result.message };
  }

  // Search users
  async searchUsers(query: string): Promise<{ success: boolean; users?: SASUser[]; message?: string }> {
    const result = await this.makeRequest<{ data: SASUser[] }>('GET', `/index/user?search=${encodeURIComponent(query)}`);

    if (result.success && result.data) {
      return { success: true, users: result.data.data || [] };
    }

    return { success: false, message: result.message };
  }

  // Get user details
  async getUser(userId: number): Promise<{ success: boolean; user?: SASUser; message?: string }> {
    const result = await this.makeRequest<SASUser>('GET', `/user/${userId}`);

    if (result.success && result.data) {
      return { success: true, user: result.data };
    }

    return { success: false, message: result.message };
  }

  // Get user overview
  async getUserOverview(userId: number): Promise<{ success: boolean; data?: object; message?: string }> {
    const result = await this.makeRequest<object>('GET', `/user/overview/${userId}`);
    return result;
  }

  // User deposit
  async userDeposit(userId: number, amount: number, comment?: string): Promise<{ success: boolean; message?: string }> {
    const result = await this.makeRequest<object>('POST', '/user/deposit', {
      user_id: userId,
      amount,
      comment,
    });
    return result;
  }

  // User withdrawal
  async userWithdraw(userId: number, amount: number, comment?: string): Promise<{ success: boolean; message?: string }> {
    const result = await this.makeRequest<object>('POST', '/user/withdraw', {
      user_id: userId,
      amount,
      comment,
    });
    return result;
  }

  // ============ ONLINE USERS ============

  // Get online users
  async getOnlineUsers(): Promise<{ success: boolean; users?: SASOnlineUser[]; message?: string }> {
    const result = await this.makeRequest<{ data: SASOnlineUser[] }>('GET', '/index/online');

    if (result.success && result.data) {
      return { success: true, users: result.data.data || [] };
    }

    return { success: false, message: result.message };
  }

  // Disconnect user
  async disconnectUser(userId: number): Promise<{ success: boolean; message?: string }> {
    const result = await this.makeRequest<object>('POST', '/user/disconnect', { user_id: userId });
    return result;
  }

  // ============ PROFILES ============

  // Get profiles list
  async getProfiles(): Promise<{ success: boolean; profiles?: SASProfile[]; message?: string }> {
    const result = await this.makeRequest<{ data: SASProfile[] }>('GET', '/list/profile/0');

    if (result.success && result.data) {
      return { success: true, profiles: result.data.data || [] };
    }

    return { success: false, message: result.message };
  }

  // ============ INVOICES ============

  // Get user invoices
  async getUserInvoices(userId: number): Promise<{ success: boolean; invoices?: SASInvoice[]; message?: string }> {
    const result = await this.makeRequest<{ data: SASInvoice[] }>('GET', `/index/UserInvoice/${userId}`);

    if (result.success && result.data) {
      return { success: true, invoices: result.data.data || [] };
    }

    return { success: false, message: result.message };
  }

  // Get all invoices
  async getAllInvoices(page: number = 1, count: number = 50): Promise<{
    success: boolean;
    invoices?: SASInvoice[];
    total?: number;
    message?: string;
  }> {
    const result = await this.makeRequest<{ data: SASInvoice[]; total?: number }>('GET', `/index/invoice?page=${page}&count=${count}`);

    if (result.success && result.data) {
      return {
        success: true,
        invoices: result.data.data || [],
        total: result.data.total,
      };
    }

    return { success: false, message: result.message };
  }

  // ============ MANAGERS ============

  // Get managers list
  async getManagers(): Promise<{ success: boolean; managers?: object[]; message?: string }> {
    const result = await this.makeRequest<{ data: object[] }>('GET', '/index/manager');

    if (result.success && result.data) {
      return { success: true, managers: result.data.data || [] };
    }

    return { success: false, message: result.message };
  }

  // ============ SYNC ============

  // Sync all data from server
  async syncAllData(onProgress?: (status: string) => void): Promise<SyncResult> {
    try {
      // Ensure logged in
      if (!this.token) {
        const loginResult = await this.login();
        if (!loginResult.success) {
          return { success: false, error: loginResult.message };
        }
      }

      let totalUsers = 0;
      let totalDevices = 0;
      let totalInvoices = 0;

      // Sync users
      onProgress?.('جاري مزامنة المشتركين...');
      const usersResult = await this.getUsers(1, 500);
      if (usersResult.success && usersResult.users) {
        totalUsers = usersResult.users.length;
      }

      // Sync online users (devices)
      onProgress?.('جاري مزامنة الأجهزة المتصلة...');
      const onlineResult = await this.getOnlineUsers();
      if (onlineResult.success && onlineResult.users) {
        totalDevices = onlineResult.users.length;
      }

      // Sync invoices
      onProgress?.('جاري مزامنة الفواتير...');
      const invoicesResult = await this.getAllInvoices(1, 200);
      if (invoicesResult.success && invoicesResult.invoices) {
        totalInvoices = invoicesResult.invoices.length;
      }

      return {
        success: true,
        usersCount: totalUsers,
        devicesCount: totalDevices,
        invoicesCount: totalInvoices,
      };
    } catch (error) {
      return { success: false, error: 'حدث خطأ أثناء المزامنة' };
    }
  }
}

// Export singleton instance
export const sasApi = new SASApiService();
export default sasApi;
